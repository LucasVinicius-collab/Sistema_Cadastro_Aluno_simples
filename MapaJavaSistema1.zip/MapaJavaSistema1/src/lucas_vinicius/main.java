package lucas_vinicius;

import telas.*;

public class main {

    public static void main(String args[]) {
        // TODO code application logic here
        new TelaAluno();   
    }
}
